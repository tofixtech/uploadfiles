<?php 

  if ($_SESSION['logado'] != 1) {
    header('Location: http://192.168.64.2/uploader');
  }
  
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Upload de arquivos - Tofix Tech</title>
  <link rel="stylesheet" href="styles-up.css">
  <link rel="stylesheet" href="global.css">
</head>
<body>
  <div id="container">
    <div id="form-file">
      <form action="upload.php" method="post">
        <div class="input-block">
          <label for="file">Arquivo</label>
          <input type="file" name="file" id="file">
        </div>
        <div class="input-block">
          <button type="submit"><span>Enviar</span></button>
        </div>
      </form>
    </div>
  </div>
</body>
</html>